import hashlib
import json
from pathlib import Path
import tarfile

base = Path(__file__).resolve().parent
assert json.loads((base / 'evidence/status.json').read_text())['status'] == 'VERIFIED'
selected = [base / name for name in ('evidence', 'SOURCE_SHA', 'source.tar', 'run.py', 'collector.log', 'package.py')]
files = sorted(p for item in selected for p in (item.rglob('*') if item.is_dir() else [item]) if p.is_file())
manifest = {p.relative_to(base).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(base / 'SHA256SUMS.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = base / 'E7-A-20261113T075315Z.tar.gz'
with tarfile.open(archive, 'w:gz') as out:
    for item in selected + [base / 'SHA256SUMS.json']:
        out.add(item, arcname=item.relative_to(base).as_posix())
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(base / 'PACKAGE.sha256').write_text(digest + '  ' + archive.name + '\n')
print('files:', len(manifest))
print('package_bytes:', archive.stat().st_size)
print('sha256:', digest)
