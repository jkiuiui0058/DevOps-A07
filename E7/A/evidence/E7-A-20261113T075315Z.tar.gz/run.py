"""One-off evidence collection; does not modify source or shared scripts."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import traceback

base = Path(__file__).resolve().parent
source = base / 'source'
evidence = base / 'evidence'
sha = 'e779b3130cd9b91eba4c6e54f4a6a85f5606b99c'
image = 'e7-buildchecker:241098114-e7-20261113t075315z'


def save(name, value):
    (evidence / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def run(name, command, cwd, timeout=180):
    folder = evidence / name
    folder.mkdir()
    (folder / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    (folder / 'cwd.txt').write_text(str(cwd) + '\n')
    with (folder / 'stdout.log').open('w') as out, (folder / 'stderr.log').open('w') as err:
        try:
            result = subprocess.run(command, cwd=cwd, stdout=out, stderr=err, timeout=timeout)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 'TIMEOUT'
    (folder / 'exit.json').write_text(json.dumps({'exit_code': code}) + '\n')
    print(name, 'exit=', code, flush=True)
    return code


def hashes(folder):
    return {p.relative_to(folder).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.rglob('*')) if p.is_file()}


def verify(project, before):
    gate = evidence / 'gate'
    summary = json.loads((gate / 'gate-result.json').read_text())
    rows = list(csv.DictReader((gate / 'results.csv').open()))
    assert summary['passed'] and len(summary['cases']) == len(rows) == 8
    for case, row in zip(summary['cases'], rows):
        assert case['passed'] and row['passed'] == 'True'
        for key in ('case', 'exit_code', 'detector_status', 'trace_id', 'error'):
            assert str(case.get(key, '')) == row[key], (case, row)
    reports = {name: json.loads((gate / name / 'evidence/findings.json').read_text())
               for name in ('original-1', 'original-2', 'original-3', 'fixed', 'build-failed', 'unsupported', 'timeout')}
    assert hashes(project / 'fixtures/md-rd') == before
    anchors = {}
    for name in ('original-1', 'original-2', 'original-3'):
        report = reports[name]
        assert report['input_sha256'] == before
        assert {(f['type'], f['target'], f['dependency']) for f in report['findings']} == {
            ('MISSING', 'main.o', 'config.h'), ('REDUNDANT', 'main.o', 'unused.h')}
        assert len(report['findings']) == 2
        assert report['clean_exit_code'] == report['build_exit_code'] == 0
        anchors[name] = []
        folder = gate / name / 'evidence'
        processes = json.loads((folder / 'processes.json').read_text())
        for finding in report['findings']:
            excerpts = []
            for anchor in finding['evidence']:
                if anchor['source'] == 'system_call':
                    path = folder / 'trace' / anchor['trace_file']
                    assert anchor['trace_file'] == f"t.{anchor['pid']}"
                    assert any(p['pid'] == anchor['pid'] for p in processes)
                    line = path.read_text().splitlines()[anchor['line'] - 1]
                    assert line.startswith(anchor['operation'] + '('), (anchor, line)
                else:
                    path = folder / anchor['artifact']
                    line = path.read_text().splitlines()[anchor['line'] - 1]
                    assert line == anchor['declaration']
                excerpts.append({'anchor': anchor, 'raw_line': line})
            anchors[name].append({'type': finding['type'], 'target': finding['target'],
                                  'dependency': finding['dependency'], 'excerpts': excerpts})
    fixed = reports['fixed']['input_sha256']
    assert set(fixed) == set(before)
    changed = [name for name in before if fixed[name] != before[name]]
    assert changed == ['Makefile']
    original_makefile = (project / 'fixtures/md-rd/Makefile').read_text()
    assert (gate / 'fixed/fixture/Makefile').read_text() == original_makefile.replace(
        'main.o: main.c unused.h', 'main.o: main.c config.h')
    assert reports['fixed']['findings'] == []
    assert reports['fixed']['build_exit_code'] == reports['fixed']['clean_exit_code'] == 0
    failed = reports['build-failed']
    assert failed['status'] == 'FAILED' and failed['error_code'] == 'CHECK_FAILED'
    assert failed['build_exit_code'] != 0 and failed['clean_exit_code'] == 0
    assert reports['unsupported']['error_code'] == 'UNSUPPORTED'
    assert reports['unsupported']['build_exit_code'] == 0
    assert reports['timeout']['status'] == 'TIMED_OUT'
    assert reports['timeout']['error_code'] == 'TIMEOUT'
    save('trace-anchors.json', anchors)
    save('verification.json', {'passed': True, 'source_sha': sha, 'image': image,
         'json_csv_eight_rows_match': True, 'original_fixture_unchanged': True,
         'original_three_inputs_identical': True, 'fixed_changed_files': changed,
         'build_failed_real_build_exit': failed['build_exit_code'], 'cases': summary['cases']})


def main():
    evidence.mkdir()
    actual = hashlib.sha256((base / 'source.tar').read_bytes()).hexdigest()
    assert actual == '719b430cdf927dbe5258a245c82d2fab2cdb07a196575359eb7643d4dd5e2489'
    source.mkdir()
    with tarfile.open(base / 'source.tar') as archive:
        archive.extractall(source, filter='data')
    (base / 'SOURCE_SHA').write_text(sha + '\n')
    save('provenance.json', {'source_sha': sha, 'source_archive_sha256': actual,
         'source_type': 'git archive of committed HEAD; extracted directory is not a Git worktree',
         'image': image})
    project = source / 'A-buildchecker'
    save('source-files-sha256.json', hashes(project))
    for name in ('requirements-dev.lock', 'services/buildchecker/Dockerfile'):
        target = evidence / Path(name).name
        target.write_bytes((project / name).read_bytes())
    commands = [
        ('docker-version', ['docker', 'version']),
        ('docker-resources', ['docker', 'info', '--format', 'CPUs={{.NCPU}} Memory={{.MemTotal}} Running={{.ContainersRunning}}']),
        ('active-containers', ['docker', 'ps', '--format', '{{.ID}} {{.Image}} {{.Status}}']),
        ('resources', ['sh', '-c', 'date -u; nproc; free -m; df -h .; uptime']),
        ('host-tools', ['sh', '-c', 'python3 --version; git --version; make --version; docker compose version; docker buildx version']),
    ]
    for name, command in commands:
        assert run(name, command, project) == 0
    before = hashes(project / 'fixtures/md-rd')
    save('fixture-before.json', before)
    code = run('build', ['docker', 'build', '--progress=plain', '-f', 'services/buildchecker/Dockerfile', '-t', image, '.'], project, 600)
    if code != 0:
        save('status.json', {'status': 'BLOCKED', 'step': 'build', 'exit_code': code})
        return
    assert run('image-inspect', ['docker', 'image', 'inspect', image], project) == 0
    assert run('toolchain', ['docker', 'run', '--rm', '--network', 'none', image, 'cat', '/opt/toolchain.lock'], project) == 0
    prefix = ['docker', 'run', '--rm', '--network', 'none', '--cpus', '2', '--memory', '1g', '--pids-limit', '256', image]
    assert run('a01', prefix + ['python3', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_e7_a.py', '-v'], project) == 0
    assert run('service-tests', prefix + ['pytest', '-v'], project) == 0
    assert run('independent-six', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'tests/e7', '-v'], project) == 0
    code = run('full-gate', ['python3', '-B', 'scripts/run_e7_a_gate.py', '--image', image, '--out', str(evidence / 'gate')], project, 600)
    save('fixture-after.json', hashes(project / 'fixtures/md-rd'))
    assert code == 0
    verify(project, before)
    save('status.json', {'status': 'VERIFIED', 'source_sha': sha})


try:
    main()
except Exception:
    evidence.mkdir(exist_ok=True)
    (evidence / 'collector-error.log').write_text(traceback.format_exc())
    save('status.json', {'status': 'BLOCKED', 'step': 'collector-or-verification'})
    raise
